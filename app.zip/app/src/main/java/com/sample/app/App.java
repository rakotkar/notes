package com.sample.app;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ExecutionException;

public class App {

	public static void main(String[] args) throws InterruptedException, ExecutionException {
		
		DataLoadService dataLoadService=new DataLoadService();
		List<ApiCallModel> list=Arrays.asList(getService1(),getService2(),getService3());
		
		for (ApiCallModel apiCallModel : list) {
			dataLoadService.callService(apiCallModel.getApiUrls());
		}
		
		System.out.println(getService1().getApiUrls());

	}
	
	
	
	private static ApiCallModel getService1(){
	List<Integer> list=Arrays.asList(1001,1002,1003,1004,1005,1006,1007,1008)	;
	return new ApiCallModel("host1", "getAdvertisements", list, "https", "https://errorhost:9000/getAdvertisements");
		
	}
	
	private static ApiCallModel getService2(){
		List<Integer> list=Arrays.asList(2001,2002,2003,2004,2005,2006,2007,2008)	;
		return new ApiCallModel("host2", "getFirmData", list, "https", "https://errorhost:9000/getFirmData");
	}


	private static ApiCallModel getService3(){

		List<Integer> list=Arrays.asList(3001,3003,3003,3004,3005,3006,3007,3008)	;
		return new ApiCallModel("host3", "getSalesData", list, "https", "https://errorhost:9000/getSalesData");
	
	
}

}
