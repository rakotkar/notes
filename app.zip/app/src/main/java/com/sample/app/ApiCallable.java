package com.sample.app;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.concurrent.Callable;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;

public class ApiCallable implements Callable<String> {

	String url;

	String errorUrl;

	public ApiCallable(String url, String errorUrl) {
		this.url = url;
		this.errorUrl = errorUrl;
	}

	@Override
	public String call() throws Exception {
		return callApiForGet(this.url, this.errorUrl); //just like c++ load method
	}

	private String callApiForGet(String url, String errorUrl) {

		try {
			return callApi(url);
		} catch (Exception e) {
			try {
				return callApi(errorUrl);
			} catch (ClientProtocolException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			return null;
		}

	}

	private String callApi(String url) throws IOException, ClientProtocolException {
		StringBuffer jsonString = new StringBuffer("");
		HttpResponse response;
		CloseableHttpClient httpclient = HttpClients.createDefault();
		HttpGet httpget = new HttpGet(url);
		response = httpclient.execute(httpget);

		// Get the response
		BufferedReader rd = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));

		String line = "";
		while ((line = rd.readLine()) != null) {

			jsonString.append(line);
		}
		return jsonString.toString();
	}

}
