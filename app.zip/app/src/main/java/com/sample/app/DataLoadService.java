package com.sample.app;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * Hello world!
 *
 */
public class DataLoadService 
{
	

	public static List<String> callService(Map<String,String> apiUrlMap) throws InterruptedException, ExecutionException {
		ExecutorService workerThreadPool= Executors.newFixedThreadPool(8);
		 
		List<ApiCallable> callables = new ArrayList<>();
		List<String> responseList=new ArrayList<>();
		for (Entry<String,String> url : apiUrlMap.entrySet()) {
			callables.add(new ApiCallable(url.getKey(), url.getValue()));
		}
				
		List<Future<String>> futures = workerThreadPool.invokeAll(callables);
		
		for (Iterator<Future<String>> iterator = futures.iterator(); iterator.hasNext();) {
			
			Future<String> future = (Future<String>) iterator.next();
           if(future.isDone()) {
        	   responseList.add(future.get());
           }
		}
		return responseList;
	}
}
