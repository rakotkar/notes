package com.sample.app;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ApiCallModel {

	String host;

	String endPoint;

	List<Integer> portNumbers;

	String protocol;

	String errorUrl;

	public ApiCallModel(String host, String endPoint, List<Integer> portNumbers, String protocol, String errorUrl) {
		super();
		this.host = host;
		this.endPoint = endPoint;
		this.portNumbers = portNumbers;
		this.protocol = protocol;
		this.errorUrl = errorUrl;
	}

	Map<String, String> getApiUrls() {

		Map<String, String> urls = new HashMap<String, String>();

		for (Integer port : portNumbers) {
			urls.put(protocol + ":" + "//" + host + ":" + port + "/" + endPoint, errorUrl);
		}
		return urls;
	}
}