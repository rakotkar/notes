package com.watchsale.repository;

import org.springframework.data.repository.CrudRepository;

import com.watchsale.entity.Product;
import com.watchsale.entity.PurchaseOrder;

public interface PurchaseOrderRepository extends CrudRepository<PurchaseOrder, Integer> {

	PurchaseOrder findBySale_discounts_product(Product product);
	
	PurchaseOrder findByCustomerId(Integer custId);

}
