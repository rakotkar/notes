package com.watchsale.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.watchsale.entity.Sale;

public interface SaleRepository extends CrudRepository<Sale, Integer> {

	@Query("from Sale sale where sysdate() between sale.startTime and sale.endTime")
	List<Sale>	getActiveSale();
}
