package com.watchsale.repository;

import org.springframework.data.repository.CrudRepository;

import com.watchsale.entity.Product;

public interface ProductRepository extends CrudRepository<Product,Integer>{

}
