package com.watchsale.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "discount", catalog = "app")
public class Discount {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	int discId;

	@OneToOne
	@JoinColumn(name = "productId")
	Product product;

	@Column
	Double percentage;

	public int getDiscId() {
		return discId;
	}

	public void setDiscId(int disdId) {
		this.discId = disdId;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public Double getPercentage() {
		return percentage;
	}

	public void setPercentage(Double percentage) {
		this.percentage = percentage;
	}

}
