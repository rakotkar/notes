package com.watchsale;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.watchsale.repository.PurchaseOrderRepository;
import com.watchsale.repository.SaleRepository;

@SpringBootApplication
@EnableJpaRepositories(basePackages="com.watchsale.repository")
public class SaleServiceApplication implements CommandLineRunner {

	
	@Autowired
	PurchaseOrderRepository orderRepository;
	
	@Autowired
	SaleRepository salRepository;
	public static void main(String[] args) {
		SpringApplication.run(SaleServiceApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		salRepository.getActiveSale();
	}

}
