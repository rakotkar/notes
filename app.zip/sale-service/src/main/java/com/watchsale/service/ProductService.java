package com.watchsale.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.watchsale.dto.PurchaseOrderResponse;
import com.watchsale.entity.Product;
import com.watchsale.entity.PurchaseOrder;
import com.watchsale.repository.ProductRepository;
import com.watchsale.repository.PurchaseOrderRepository;

@Service
public class ProductService {

	@Autowired
	ProductRepository productRepository;

	@Autowired
	PurchaseOrderRepository purchaseOrderRepository;

	public ResponseEntity<Product> getProduct(int productId) {
		Optional<Product> product = productRepository.findById(productId);
		return new ResponseEntity<Product>(product.get(), HttpStatus.OK);

	}

	public ResponseEntity<Product> addProduct(Product product) {
		Product savedProduct = productRepository.save(product);
		return new ResponseEntity<Product>(savedProduct, HttpStatus.OK);

	}

	public ResponseEntity<PurchaseOrderResponse> getPurchaseOrders(Product product) {
		PurchaseOrder savedProduct = purchaseOrderRepository.findBySale_discounts_product(product);
		return new ResponseEntity<PurchaseOrderResponse>(new PurchaseOrderResponse(), HttpStatus.OK);

	}
	public ResponseEntity<PurchaseOrderResponse> getPurchaseOrdersByCustId(Integer custId) {
		PurchaseOrder savedProduct = purchaseOrderRepository.findByCustomerId(custId);
		return new ResponseEntity<PurchaseOrderResponse>(new PurchaseOrderResponse(), HttpStatus.;OK);

	}

	public ResponseEntity<PurchaseOrder> savePurchaseOrder(PurchaseOrder purchaseOrder) {
		PurchaseOrder savedProduct = purchaseOrderRepository.save(purchaseOrder);
		return new ResponseEntity<PurchaseOrder>(savedProduct, HttpStatus.OK);

	}

}
