package com.watchsale.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.watchsale.entity.Sale;
import com.watchsale.repository.SaleRepository;

public class SaleService {
	
	@Autowired
	SaleRepository saleRepository;
    
	public Sale getOnGoingSale(){
		
		return null;
	}
	
	public Sale getSaleForProduct() {
		
		return null;
	}
	
}
