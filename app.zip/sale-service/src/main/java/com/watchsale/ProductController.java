package com.watchsale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.watchsale.entity.Product;
import com.watchsale.entity.PurchaseOrder;
import com.watchsale.service.ProductService;


@RestController
public class ProductController {
	
	@Autowired
	ProductService service;
	
	@PostMapping("/addProduct")
	public ResponseEntity<Product> addProduct(@RequestBody Product product) {
	
		return 	service.addProduct(product);
	}

	@GetMapping("/getProduct/{productId}")
	public ResponseEntity<Product> getProduct(int productId) {

		return service.getProduct(productId);
	}

	@PostMapping("/buyProduct")
	public ResponseEntity<PurchaseOrder> buyProduct(PurchaseOrder purchaseOrder) {
		
		return service.savePurchaseOrder(purchaseOrder);
	}

	@GetMapping("/getPurchaseOrders/{custId}")
	public ResponseEntity<PurchaseOrder> getPurchaseOrders(@PathVariable("custId") Integer custId) {
		
		return service.getPurchaseOrders(custId);
	}

}
