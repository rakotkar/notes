Import the project as gradle project in IDE or to directly execute run below commands
 gradle bootJar

Exectutabl jar is created just run that jar file:

java -jar <jar_name>

Run Project in IDE : Application.java -> right click and run a java application.

 

Once the Application started, you can able to browse UI at http://localhost:8080/patients

sql script is attached, please import the script in any mysql server. It also includes create database statement so no need to manually create db.

please update below properties in application.properties:

spring.datasource.url=jdbc:mysql://localhost:3306/phr?useSSL=true
spring.datasource.username=root
spring.datasource.password=root

