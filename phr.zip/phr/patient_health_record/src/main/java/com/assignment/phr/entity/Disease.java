/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.assignment.phr.entity;

import java.io.Serializable;
import java.util.Set;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

@Entity
@Table(name = "disease")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Disease.findAll", query = "SELECT d FROM Disease d")
    , @NamedQuery(name = "Disease.findById", query = "SELECT d FROM Disease d WHERE d.id = :id")
    , @NamedQuery(name = "Disease.findByName", query = "SELECT d FROM Disease d WHERE d.name = :name")
    , @NamedQuery(name = "Disease.findByType", query = "SELECT d FROM Disease d WHERE d.type = :type")
    , @NamedQuery(name = "Disease.findByCurable", query = "SELECT d FROM Disease d WHERE d.curable = :curable")
    , @NamedQuery(name = "Disease.findByProneTo", query = "SELECT d FROM Disease d WHERE d.proneTo = :proneTo")
    , @NamedQuery(name = "Disease.findByDescription", query = "SELECT d FROM Disease d WHERE d.description = :description")})
public class Disease implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Column(name = "name")
    private String name;
    @Column(name = "type")
    private String type;
    @Column(name = "curable")
    private String curable;
    @Column(name = "prone_to")
    private Integer proneTo;
    @Column(name = "description")
    private String description;
    @OneToMany(mappedBy = "disease")
    private Set<PatientHelthRecord> patientHelthRecordSet;

    public Disease() {
    }

    public Disease(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getCurable() {
        return curable;
    }

    public void setCurable(String curable) {
        this.curable = curable;
    }

    public Integer getProneTo() {
        return proneTo;
    }

    public void setProneTo(Integer proneTo) {
        this.proneTo = proneTo;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @XmlTransient
    public Set<PatientHelthRecord> getPatientHelthRecordSet() {
        return patientHelthRecordSet;
    }

    public void setPatientHelthRecordSet(Set<PatientHelthRecord> patientHelthRecordSet) {
        this.patientHelthRecordSet = patientHelthRecordSet;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Disease)) {
            return false;
        }
        Disease other = (Disease) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.assignment.phr.entity.Disease[ id=" + id + " ]";
    }
    
}
