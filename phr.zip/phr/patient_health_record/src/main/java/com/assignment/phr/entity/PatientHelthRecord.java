/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.assignment.phr.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

@Entity
@Table(name = "patient_helth_record")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "PatientHelthRecord.findAll", query = "SELECT p FROM PatientHelthRecord p")
    , @NamedQuery(name = "PatientHelthRecord.findById", query = "SELECT p FROM PatientHelthRecord p WHERE p.id = :id")
    , @NamedQuery(name = "PatientHelthRecord.findByTreatmentDate", query = "SELECT p FROM PatientHelthRecord p WHERE p.treatmentDate = :treatmentDate")
    , @NamedQuery(name = "PatientHelthRecord.findByDescription", query = "SELECT p FROM PatientHelthRecord p WHERE p.description = :description")})
public class PatientHelthRecord implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Column(name = "treatment_date")
    @Temporal(TemporalType.DATE)
    private Date treatmentDate;
    @Column(name = "description")
    private String description;
    @JoinTable(name = "patient_surgery", joinColumns = {
        @JoinColumn(name = "health_record_id", referencedColumnName = "id")}, inverseJoinColumns = {
        @JoinColumn(name = "surgery_id", referencedColumnName = "id")})
    @ManyToMany
    private Set<Surgery> surgerySet;
    @JoinTable(name = "patient_medicine", joinColumns = {
        @JoinColumn(name = "health_record_id", referencedColumnName = "id")}, inverseJoinColumns = {
        @JoinColumn(name = "medicine_id", referencedColumnName = "id")})
    @ManyToMany
    private Set<Medicines> medicinesSet;
    @ManyToMany(mappedBy = "patientHelthRecordSet")
    private Set<Checkups> checkupsSet;
    @JoinColumn(name = "disease", referencedColumnName = "id")
    @ManyToOne
    private Disease disease;
    @JoinColumn(name = "patient_id", referencedColumnName = "id")
    @ManyToOne
    private Patient patientId;

    public PatientHelthRecord() {
    }

    public PatientHelthRecord(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Date getTreatmentDate() {
        return treatmentDate;
    }

    public void setTreatmentDate(Date treatmentDate) {
        this.treatmentDate = treatmentDate;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @XmlTransient
    public Set<Surgery> getSurgerySet() {
        return surgerySet;
    }

    public void setSurgerySet(Set<Surgery> surgerySet) {
        this.surgerySet = surgerySet;
    }

    @XmlTransient
    public Set<Medicines> getMedicinesSet() {
        return medicinesSet;
    }

    public void setMedicinesSet(Set<Medicines> medicinesSet) {
        this.medicinesSet = medicinesSet;
    }

    @XmlTransient
    public Set<Checkups> getCheckupsSet() {
        return checkupsSet;
    }

    public void setCheckupsSet(Set<Checkups> checkupsSet) {
        this.checkupsSet = checkupsSet;
    }

    public Disease getDisease() {
        return disease;
    }

    public void setDisease(Disease disease) {
        this.disease = disease;
    }

    public Patient getPatientId() {
        return patientId;
    }

    public void setPatientId(Patient patientId) {
        this.patientId = patientId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof PatientHelthRecord)) {
            return false;
        }
        PatientHelthRecord other = (PatientHelthRecord) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.assignment.phr.entity.PatientHelthRecord[ id=" + id + " ]";
    }
    
}
