/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.assignment.phr.dto;

import java.io.Serializable;

public class Disease implements Serializable {

    private static final long serialVersionUID = 1L;
    private String name;
    private String type;
    private String curable;
    private Integer proneTo;
    private String description;

    public Disease() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getCurable() {
        return curable;
    }

    public void setCurable(String curable) {
        this.curable = curable;
    }

    public Integer getProneTo() {
        return proneTo;
    }

    public void setProneTo(Integer proneTo) {
        this.proneTo = proneTo;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

}
