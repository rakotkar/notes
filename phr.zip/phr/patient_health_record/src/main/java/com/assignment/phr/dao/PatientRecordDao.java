package com.assignment.phr.dao;

import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import com.assignment.phr.entity.Patient;

import org.springframework.data.jpa.repository.JpaRepository;

@RepositoryRestResource
public interface PatientRecordDao extends JpaRepository<Patient, Integer> {

}
