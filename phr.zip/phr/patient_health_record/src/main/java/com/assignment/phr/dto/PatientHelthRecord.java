/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.assignment.phr.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;

import javax.xml.bind.annotation.XmlTransient;

public class PatientHelthRecord implements Serializable {

    private static final long serialVersionUID = 1L;
    private Date treatmentDate;
    private String description;
    private Set<Surgery> surgerySet;
    private Set<Medicines> medicinesSet;
    private Set<Checkups> checkupsSet;
    private Disease disease;

    public PatientHelthRecord() {
    }

    public Date getTreatmentDate() {
        return treatmentDate;
    }

    public void setTreatmentDate(Date treatmentDate) {
        this.treatmentDate = treatmentDate;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @XmlTransient
    public Set<Surgery> getSurgerySet() {
        return surgerySet;
    }

    public void setSurgerySet(Set<Surgery> surgerySet) {
        this.surgerySet = surgerySet;
    }

    @XmlTransient
    public Set<Medicines> getMedicinesSet() {
        return medicinesSet;
    }

    public void setMedicinesSet(Set<Medicines> medicinesSet) {
        this.medicinesSet = medicinesSet;
    }

    @XmlTransient
    public Set<Checkups> getCheckupsSet() {
        return checkupsSet;
    }

    public void setCheckupsSet(Set<Checkups> checkupsSet) {
        this.checkupsSet = checkupsSet;
    }

    public Disease getDisease() {
        return disease;
    }

    public void setDisease(Disease disease) {
        this.disease = disease;
    }
    
}
