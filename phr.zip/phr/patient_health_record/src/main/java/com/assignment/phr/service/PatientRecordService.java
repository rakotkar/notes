package com.assignment.phr.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.assignment.phr.dao.PatientRecordDao;
import com.assignment.phr.entity.Patient;

@Service
public class PatientRecordService {
	
	@Autowired
	private PatientRecordDao patientRecordDao;
	
	public List<Patient> getPatients() {
		return patientRecordDao.findAll();
	}
	
    public Patient getPatient(String id) {
    	if(id.matches("-?(0|[1-9]\\d*)")) {
    		return patientRecordDao.findById(Integer.parseInt(id)).orElseThrow(() -> new IllegalArgumentException("Invalid patient Id:" + id));
    	} else {
    		throw new IllegalArgumentException("Invalid patient Id:" + id);
    	}
	}

}
