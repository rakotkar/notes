/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.assignment.phr.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;

import javax.xml.bind.annotation.XmlTransient;

public class Patient implements Serializable {

    private static final long serialVersionUID = 1L;
    private String firstName;
    private String lastName;
    private Integer age;
    private Date dob;
    private String gender;
    private Set<Allergies> allergiesSet;
    private Address address;
    private Set<PatientHelthRecord> patientHelthRecordSet;

    public Patient() {
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public Date getDob() {
        return dob;
    }

    public void setDob(Date dob) {
        this.dob = dob;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    @XmlTransient
    public Set<Allergies> getAllergiesSet() {
        return allergiesSet;
    }

    public void setAllergiesSet(Set<Allergies> allergiesSet) {
        this.allergiesSet = allergiesSet;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    @XmlTransient
    public Set<PatientHelthRecord> getPatientHelthRecordSet() {
        return patientHelthRecordSet;
    }

    public void setPatientHelthRecordSet(Set<PatientHelthRecord> patientHelthRecordSet) {
        this.patientHelthRecordSet = patientHelthRecordSet;
    }
    
}
