package com.assignment.phr.web;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.assignment.phr.dto.Address;
import com.assignment.phr.dto.Allergies;
import com.assignment.phr.dto.Checkups;
import com.assignment.phr.dto.Disease;
import com.assignment.phr.dto.Medicines;
import com.assignment.phr.dto.Patient;
import com.assignment.phr.dto.PatientHelthRecord;
import com.assignment.phr.dto.Surgery;
import com.assignment.phr.service.PatientRecordService;

@RestController
public class PatientHistoryController {
	
	@Autowired
	private PatientRecordService patientRecordService;

	@RequestMapping(value="/patients", method=RequestMethod.GET, produces={"application/json","application/xml"})
	public List<Patient> getAllPatients() throws IllegalAccessException, InvocationTargetException {
		return getPatientRecord(patientRecordService.getPatients());
	}
	
	private List<Patient> getPatientRecord(List<com.assignment.phr.entity.Patient> patients) throws IllegalAccessException, InvocationTargetException {
		List<Patient> patientsList = new ArrayList<>();
		for(com.assignment.phr.entity.Patient patient : patients) {
			Patient patient2 = new Patient();
			Address address = new Address();
			BeanUtils.copyProperties(address, patient.getAddress());
			patient2.setAddress(address);
			
			patient2.setAge(patient.getAge());
			patient2.setDob(patient.getDob());
			patient2.setFirstName(patient.getFirstName());
			patient2.setGender(patient.getGender());
			patient2.setLastName(patient.getLastName());
			
			Set<Allergies> allergiesSet = new HashSet<>();
			for(com.assignment.phr.entity.Allergies allergies : patient.getAllergiesSet()) {
				Allergies allergy = new Allergies();
				BeanUtils.copyProperties(allergy, allergies);
				allergiesSet.add(allergy);
			}
			patient2.setAllergiesSet(allergiesSet);
			
			Set<PatientHelthRecord> patientHelthRecordSet = new HashSet<>();
			for(com.assignment.phr.entity.PatientHelthRecord patientHelthRecord : patient.getPatientHelthRecordSet()) {
				PatientHelthRecord patientHelthRecord2 = new PatientHelthRecord();
				
				patientHelthRecord2.setTreatmentDate(patientHelthRecord.getTreatmentDate());
				patientHelthRecord2.setDescription(patientHelthRecord.getDescription());			
				
				Disease disease = new Disease();
				BeanUtils.copyProperties(disease, patientHelthRecord.getDisease());
				patientHelthRecord2.setDisease(disease);
				
				Set<Checkups> checkupsSet = new HashSet<>();
				for(com.assignment.phr.entity.Checkups checkup : patientHelthRecord.getCheckupsSet()) {
					Checkups checkup2 = new Checkups();
					BeanUtils.copyProperties(checkup2, checkup);
					checkupsSet.add(checkup2);
				}
				patientHelthRecord2.setCheckupsSet(checkupsSet);
				
				Set<Medicines> medicinesSet = new HashSet<>();
				for(com.assignment.phr.entity.Medicines medicines : patientHelthRecord.getMedicinesSet()) {
					Medicines medicines2 = new Medicines();
					BeanUtils.copyProperties(medicines2, medicines);
					medicinesSet.add(medicines2);
				}
				patientHelthRecord2.setMedicinesSet(medicinesSet);
				
				Set<Surgery> surgerySet = new HashSet<>();
				for(com.assignment.phr.entity.Surgery surgery : patientHelthRecord.getSurgerySet()) {
					Surgery surgery2 = new Surgery();
					BeanUtils.copyProperties(surgery2, surgery);
					surgerySet.add(surgery2);					
				}
				patientHelthRecord2.setSurgerySet(surgerySet);
				
				patientHelthRecordSet.add(patientHelthRecord2);
				
			}
			patient2.setPatientHelthRecordSet(patientHelthRecordSet);
			
			patientsList.add(patient2);
		}
		return patientsList;
	}
}
